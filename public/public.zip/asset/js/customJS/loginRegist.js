 var animation = bodymovin.loadAnimation({
            container: document.getElementById('anim'),
            render: 'svg',
            loop: true,
            autoplay: true,
            path: '/asset/data.json'
        });

        var animation2 = bodymovin.loadAnimation({
            container: document.getElementById('anim2'),
            render: 'svg',
            loop: true,
            autoplay: true,
            path: '/asset/data.json'
        });

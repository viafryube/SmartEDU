    document.addEventListener("DOMContentLoaded", function() {
            window.scrollTo(0, document.body.scrollHeight);
        });
